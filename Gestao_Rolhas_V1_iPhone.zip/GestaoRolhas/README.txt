GESTÃO ROLHAS — VERSÃO 1

É uma PWA (app web instalável) para iPhone.
Inclui: dashboard, matéria-prima por calibre/qualidade, produção com capacidade personalizada, rectificação, residuais e armazenamento local no dispositivo.

Para instalar no iPhone: publicar estes ficheiros num endereço HTTPS e abrir no Safari. Depois usar Partilhar > Adicionar ao Ecrã principal.
